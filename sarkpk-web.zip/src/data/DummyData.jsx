export const BoxData = [
    {
        id: '1',
        img: 'https://lh3.googleusercontent.com/8i47zYp_vOf0P98U6FfyN-hWGN_7l5DxQ8_EB2mIWzclRCiFK_hw9Mp-GRPllS46YT-Wy1RfRJgKaIJ9-sKQVT_echnjXyCUWOcH=w600',
        text: 'Text'
    },
    {
        id: '2',
        img: 'https://lh3.googleusercontent.com/8i47zYp_vOf0P98U6FfyN-hWGN_7l5DxQ8_EB2mIWzclRCiFK_hw9Mp-GRPllS46YT-Wy1RfRJgKaIJ9-sKQVT_echnjXyCUWOcH=w600',
        text: 'Text'
    },
    {
        id: '3',
        img: 'https://lh3.googleusercontent.com/8i47zYp_vOf0P98U6FfyN-hWGN_7l5DxQ8_EB2mIWzclRCiFK_hw9Mp-GRPllS46YT-Wy1RfRJgKaIJ9-sKQVT_echnjXyCUWOcH=w600',
        text: 'Text'
    },
    {
        id: '4',
        img: 'https://lh3.googleusercontent.com/8i47zYp_vOf0P98U6FfyN-hWGN_7l5DxQ8_EB2mIWzclRCiFK_hw9Mp-GRPllS46YT-Wy1RfRJgKaIJ9-sKQVT_echnjXyCUWOcH=w600',
        text: 'Text'
    }
];

export const TextBoxData = [
    {
        id: '1',
        title: 'Text Box',
        desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias autem odio voluptatibus? Deserunt, culpa, '
    },
    {
        id: '2',
        title: 'Text Box',
        desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias autem odio voluptatibus? Deserunt, culpa,'
    },
    {
        id: '3',
        title: 'Text Box',
        desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias autem odio voluptatibus? Deserunt, culpa,'
    },
    {
        id: '4',
        title: 'Text Box',
        desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias autem odio voluptatibus? Deserunt, culpa,'
    }
];
